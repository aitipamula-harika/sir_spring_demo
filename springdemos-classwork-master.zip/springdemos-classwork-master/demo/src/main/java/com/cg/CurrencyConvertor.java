package com.cg;

public interface CurrencyConvertor {
	
	public double dollarsToRupees(double dollars);
	
	
	
	

}
